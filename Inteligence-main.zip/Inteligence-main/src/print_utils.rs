
pub fn print_info(content: &str) {
    println!("INFO :{}", content);
}

pub fn print_error(content: &str) {
    println!("ERROR :{}", content);
}

pub fn print_debug(content: &str) {
    println!("DEBUG :{}", content);
}


